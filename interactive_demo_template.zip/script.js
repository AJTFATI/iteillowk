document.addEventListener("DOMContentLoaded", () => {
    const audio = document.getElementById("background-music");
    const playButton = document.getElementById("play-music");

    // Play Music on Button Click
    playButton.addEventListener("click", () => {
        if (audio.paused) {
            audio.play();
            playButton.textContent = "Pause Music";
        } else {
            audio.pause();
            playButton.textContent = "Play Music";
        }
    });

    // GSAP ScrollTrigger for Animation
    gsap.registerPlugin(ScrollTrigger);

    gsap.from(".animated-section h2, .animated-section p", {
        scrollTrigger: {
            trigger: ".animated-section",
            start: "top center",
            end: "bottom center",
            scrub: true,
        },
        y: 100,
        opacity: 0,
    });
});
